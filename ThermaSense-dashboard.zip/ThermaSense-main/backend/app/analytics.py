"""
analytics.py

Aggregate / cross-ward endpoints for the command-centre dashboard.

These sit alongside wards.py (which handles single-ward geojson +
per-ward forecast) and add the citywide views the dashboard needs:

- /wards/priority        one row per ward: current risk, forecast peak
                          (next 5 days), trend, and forecast-based warning
- /wards/{id}/drivers    latest raw weather inputs for one ward
- /forecast/outlook      citywide peak-risk profile per day, next 5 days
- /alerts                dispatched alert history (alerts_log)

All logic mirrors the thresholds/semantics already used in
forecast_alert_engine.py and risk_scoring.py (final_risk_band falls back
to risk_band, final_risk_score falls back to risk_score_raw, "high"/
"extreme" are the alertable bands, 5-day forecast horizon). Nothing here
invents a metric the backend doesn't compute.
"""

from collections import defaultdict
from datetime import datetime, timezone

from fastapi import APIRouter, Query
from sqlalchemy import text

from db import engine

router = APIRouter()

ALERT_BANDS = {"high", "extreme"}
TREND_THRESHOLD = 3.0  # points of final risk score to call it a real move


def _to_float(value):
    return float(value) if value is not None else None


def _iso(value):
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


def _band(row, prefix=""):
    return row[f"{prefix}final_risk_band"] or row[f"{prefix}risk_band"]


def _score(row, prefix=""):
    final = row[f"{prefix}final_risk_score"]
    return _to_float(final) if final is not None else _to_float(row[f"{prefix}risk_score_raw"])


@router.get("/wards/priority")
def get_ward_priority():
    """
    One row per ward for the Ward Priority Queue / Early Warning Panel /
    executive summary strip.

    current   -> latest is_forecast = FALSE row
    near      -> earliest future is_forecast = TRUE row (used for trend)
    peak      -> highest-risk future row within the next 5 days
                 (used for the forecast-based warning + "peak forecast")
    """
    query = text("""
        SELECT
            w.id, w.name, w.city,

            cur.score_time      AS cur_time,
            cur.risk_band       AS cur_risk_band,
            cur.final_risk_band AS cur_final_risk_band,
            cur.risk_score_raw  AS cur_risk_score_raw,
            cur.final_risk_score AS cur_final_risk_score,

            near.score_time      AS near_time,
            near.risk_band       AS near_risk_band,
            near.final_risk_band AS near_final_risk_band,
            near.risk_score_raw  AS near_risk_score_raw,
            near.final_risk_score AS near_final_risk_score,

            peak.score_time      AS peak_time,
            peak.risk_band       AS peak_risk_band,
            peak.final_risk_band AS peak_final_risk_band,
            peak.risk_score_raw  AS peak_risk_score_raw,
            peak.final_risk_score AS peak_final_risk_score
        FROM wards w
        LEFT JOIN LATERAL (
            SELECT * FROM risk_scores r
            WHERE r.ward_id = w.id AND r.is_forecast = FALSE
            ORDER BY r.score_time DESC, r.id DESC
            LIMIT 1
        ) cur ON TRUE
        LEFT JOIN LATERAL (
            SELECT * FROM risk_scores r
            WHERE r.ward_id = w.id AND r.is_forecast = TRUE
              AND r.score_time > NOW()
            ORDER BY r.score_time ASC, r.id ASC
            LIMIT 1
        ) near ON TRUE
        LEFT JOIN LATERAL (
            SELECT * FROM risk_scores r
            WHERE r.ward_id = w.id AND r.is_forecast = TRUE
              AND r.score_time > NOW()
              AND r.score_time <= NOW() + INTERVAL '5 days'
            ORDER BY COALESCE(r.final_risk_score, r.risk_score_raw) DESC NULLS LAST,
                     r.score_time ASC
            LIMIT 1
        ) peak ON TRUE
        ORDER BY COALESCE(cur.final_risk_score, cur.risk_score_raw) DESC NULLS LAST
    """)

    with engine.connect() as conn:
        rows = [dict(r._mapping) for r in conn.execute(query).fetchall()]

    now = datetime.now(timezone.utc)
    out = []

    for row in rows:
        has_current = row["cur_time"] is not None
        has_near = row["near_time"] is not None
        has_peak = row["peak_time"] is not None

        current_score = _score(row, "cur_") if has_current else None
        near_score = _score(row, "near_") if has_near else None

        trend = "unknown"
        if current_score is not None and near_score is not None:
            diff = near_score - current_score
            if diff > TREND_THRESHOLD:
                trend = "increasing"
            elif diff < -TREND_THRESHOLD:
                trend = "decreasing"
            else:
                trend = "stable"

        warning = None
        if has_peak:
            peak_band = _band(row, "peak_")
            if peak_band in ALERT_BANDS:
                peak_time = row["peak_time"]
                if peak_time.tzinfo is None:
                    peak_time = peak_time.replace(tzinfo=timezone.utc)
                lead_hours = round((peak_time - now).total_seconds() / 3600.0, 1)
                warning = {
                    "risk_band": peak_band,
                    "risk_score": _score(row, "peak_"),
                    "expected_time": _iso(row["peak_time"]),
                    "lead_time_hours": lead_hours,
                }

        out.append({
            "ward_id": row["id"],
            "ward_name": row["name"],
            "city": row["city"],
            "current": {
                "risk_band": _band(row, "cur_") if has_current else None,
                "risk_score": current_score,
                "score_time": _iso(row["cur_time"]),
            } if has_current else None,
            "forecast_peak": {
                "risk_band": _band(row, "peak_"),
                "risk_score": _score(row, "peak_"),
                "score_time": _iso(row["peak_time"]),
            } if has_peak else None,
            "trend": trend,
            "warning": warning,
            "last_updated": _iso(row["cur_time"]) if has_current else None,
        })

    return {"count": len(out), "wards": out}


@router.get("/wards/{ward_id}/drivers")
def get_ward_drivers(ward_id: int):
    """
    Latest raw weather inputs for one ward (current, not forecast) —
    powers the "Why is risk high?" risk-drivers section.
    """
    query = text("""
        SELECT reading_time, temp_c, humidity_pct, wind_speed_ms,
               solar_radiation_wm2, source
        FROM weather_readings
        WHERE ward_id = :ward_id AND is_forecast = FALSE
        ORDER BY reading_time DESC
        LIMIT 1
    """)

    with engine.connect() as conn:
        row = conn.execute(query, {"ward_id": ward_id}).fetchone()

    if not row:
        return {
            "ward_id": ward_id,
            "available": False,
            "reading_time": None,
            "temperature_c": None,
            "humidity_pct": None,
            "wind_speed_ms": None,
            "solar_radiation_wm2": None,
            "source": None,
        }

    return {
        "ward_id": ward_id,
        "available": True,
        "reading_time": _iso(row.reading_time),
        "temperature_c": _to_float(row.temp_c),
        "humidity_pct": _to_float(row.humidity_pct),
        "wind_speed_ms": _to_float(row.wind_speed_ms),
        "solar_radiation_wm2": _to_float(row.solar_radiation_wm2),
        "source": row.source,
    }


@router.get("/forecast/outlook")
def get_forecast_outlook():
    """
    Citywide peak-risk profile per day for the next 5 days.

    For each day, finds the single highest-risk forecast row across all
    wards and reports its band/score/WBGT/UTCI/heat index — a coherent
    "worst moment of that day" snapshot rather than mixing independent
    per-metric maxima.
    """
    query = text("""
        SELECT
            r.ward_id, w.name AS ward_name,
            r.score_time, r.risk_band, r.final_risk_band,
            r.risk_score_raw, r.final_risk_score,
            r.wbgt_c, r.utci_c, r.heat_index_c
        FROM risk_scores r
        JOIN wards w ON w.id = r.ward_id
        WHERE r.is_forecast = TRUE
          AND r.score_time > NOW()
          AND r.score_time <= NOW() + INTERVAL '5 days'
        ORDER BY r.score_time ASC
    """)

    with engine.connect() as conn:
        rows = [dict(r._mapping) for r in conn.execute(query).fetchall()]

    by_day = defaultdict(list)
    for row in rows:
        day_key = row["score_time"].date().isoformat()
        by_day[day_key].append(row)

    days = []
    for day_key in sorted(by_day.keys()):
        candidates = by_day[day_key]
        peak = max(candidates, key=lambda r: _score(r) or -1)

        days.append({
            "date": day_key,
            "peak_ward_id": peak["ward_id"],
            "peak_ward_name": peak["ward_name"],
            "peak_time": _iso(peak["score_time"]),
            "risk_band": _band(peak),
            "risk_score": _score(peak),
            "wbgt": _to_float(peak["wbgt_c"]),
            "utci": _to_float(peak["utci_c"]),
            "heat_index": _to_float(peak["heat_index_c"]),
        })

    return {"days": days}


@router.get("/alerts")
def get_alert_history(limit: int = Query(50, ge=1, le=500)):
    """
    Dispatched alert history from alerts_log, most recent first.
    """
    query = text("""
        SELECT a.id, a.ward_id, w.name AS ward_name, a.triggered_at,
               a.risk_band, a.channel, a.message, a.status
        FROM alerts_log a
        JOIN wards w ON w.id = a.ward_id
        ORDER BY a.triggered_at DESC
        LIMIT :limit
    """)

    with engine.connect() as conn:
        rows = conn.execute(query, {"limit": limit}).fetchall()

    alerts = [
        {
            "id": row.id,
            "ward_id": row.ward_id,
            "ward_name": row.ward_name,
            "triggered_at": _iso(row.triggered_at),
            "risk_band": row.risk_band,
            "channel": row.channel,
            "message": row.message,
            "status": row.status,
        }
        for row in rows
    ]

    return {"count": len(alerts), "alerts": alerts}
