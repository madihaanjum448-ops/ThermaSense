import { useEffect, useMemo, useState } from 'react';
import Header from './components/Header';
import RiskSummaryStrip from './components/RiskSummaryStrip';
import ThermalMap from './components/ThermalMap';
import IntelligencePanel from './components/IntelligencePanel';
import ForecastOutlook from './components/ForecastOutlook';
import WarningPanel from './components/WarningPanel';
import WardPriorityTable from './components/WardPriorityTable';
import AlertHistory from './components/AlertHistory';
import ModelInsight from './components/ModelInsight';
import { api } from './lib/api';
import { riskRank } from './lib/risk';

const POLL_MS = 60000;

export default function App() {
  const [geoData, setGeoData] = useState(null);
  const [geoError, setGeoError] = useState(false);

  const [priority, setPriority] = useState([]);
  const [outlookDays, setOutlookDays] = useState([]);
  const [alerts, setAlerts] = useState([]);

  const [selectedWardId, setSelectedWardId] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [drivers, setDrivers] = useState(null);
  const [driversLoading, setDriversLoading] = useState(false);

  const systemStatus = useMemo(() => {
    if (geoError) return 'offline';
    if (geoData && (!geoData.features || geoData.features.length === 0)) return 'degraded';
    return 'operational';
  }, [geoData, geoError]);

  // Poll the citywide data sources.
  useEffect(() => {
    let cancelled = false;

    async function loadAll() {
      try {
        const geo = await api.wardsGeojson();
        if (!cancelled) {
          setGeoData(geo);
          setGeoError(false);
        }
      } catch {
        if (!cancelled) setGeoError(true);
      }

      try {
        const p = await api.wardPriority();
        if (!cancelled) setPriority(p.wards || []);
      } catch {
        /* leave previous data in place */
      }

      try {
        const o = await api.forecastOutlook();
        if (!cancelled) setOutlookDays(o.days || []);
      } catch {
        /* leave previous data in place */
      }

      try {
        const a = await api.alerts(30);
        if (!cancelled) setAlerts(a.alerts || []);
      } catch {
        /* leave previous data in place */
      }
    }

    loadAll();
    const id = setInterval(loadAll, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  // Auto-select the highest-priority ward once data arrives.
  useEffect(() => {
    if (!selectedWardId && priority.length > 0) {
      setSelectedWardId(priority[0].ward_id);
    }
  }, [priority, selectedWardId]);

  // Load per-ward detail when selection changes.
  useEffect(() => {
    if (!selectedWardId) return;
    let cancelled = false;

    setDriversLoading(true);
    api.wardForecast(selectedWardId).then((data) => {
      if (!cancelled) setForecast(data);
    }).catch(() => { if (!cancelled) setForecast(null); });

    api.wardDrivers(selectedWardId).then((data) => {
      if (!cancelled) setDrivers(data);
    }).catch(() => { if (!cancelled) setDrivers(null); })
      .finally(() => { if (!cancelled) setDriversLoading(false); });

    return () => { cancelled = true; };
  }, [selectedWardId]);

  const selectedWardFeature = useMemo(() => {
    if (!geoData?.features || !selectedWardId) return null;
    return geoData.features.find((f) => f.properties.id === selectedWardId) || null;
  }, [geoData, selectedWardId]);

  const summary = useMemo(() => {
    if (priority.length === 0) return null;

    const currentBands = priority.map((w) => w.current?.risk_band).filter(Boolean);
    const peakBands = priority.map((w) => w.forecast_peak?.risk_band).filter(Boolean);

    const worstBand = (bands) =>
      bands.reduce((worst, b) => (riskRank(b) > riskRank(worst) ? b : worst), bands[0] || null);

    const currentBand = currentBands.length ? worstBand(currentBands) : null;
    const peakBand = peakBands.length ? worstBand(peakBands) : null;
    const peakEntry = priority.find((w) => w.forecast_peak?.risk_band === peakBand);

    const highRiskWards = priority.filter((w) =>
      ['high', 'extreme'].includes((w.current?.risk_band || '').toLowerCase())
    ).length;

    const activeWarnings = priority.filter((w) => w.warning).length;

    const lastUpdatedTimes = priority.map((w) => w.last_updated).filter(Boolean).sort();
    const lastUpdated = lastUpdatedTimes.length ? lastUpdatedTimes[lastUpdatedTimes.length - 1] : null;

    return {
      currentBand,
      peakBand,
      peakTime: peakEntry?.forecast_peak?.score_time,
      wardsMonitored: priority.length,
      highRiskWards,
      activeWarnings,
      lastUpdated,
    };
  }, [priority]);

  const activeWarnings = useMemo(
    () => priority.filter((w) => w.warning).sort((a, b) => a.warning.lead_time_hours - b.warning.lead_time_hours),
    [priority]
  );

  return (
    <div className="ts-app">
      <Header
        freshnessLabel={summary?.lastUpdated ? 'live' : 'N/A'}
        systemStatus={systemStatus}
      />

      <main className="ts-main">
        <RiskSummaryStrip summary={summary} />

        <div className="ts-content-row">
          <ThermalMap
            geoData={geoData}
            loadError={geoError}
            selectedWardId={selectedWardId}
            onSelectWard={setSelectedWardId}
          />
          <IntelligencePanel
            ward={selectedWardFeature}
            forecast={forecast}
            drivers={drivers}
            loading={driversLoading}
          />
        </div>

        <ForecastOutlook days={outlookDays} />

        <div className="ts-content-row">
          <WardPriorityTable
            wards={priority}
            onSelectWard={setSelectedWardId}
            selectedWardId={selectedWardId}
          />
          <WarningPanel warnings={activeWarnings} onSelectWard={setSelectedWardId} />
        </div>

        <div className="ts-content-row">
          <AlertHistory alerts={alerts} />
          <ModelInsight ward={selectedWardFeature} drivers={drivers} />
        </div>
      </main>
    </div>
  );
}
