import RiskBadge from './RiskBadge';
import { formatClock } from '../lib/risk';

const STATUS_COLOR = {
  sent: 'var(--status-ok)',
  delivered: 'var(--status-ok)',
  pending: 'var(--status-warn)',
  failed: 'var(--status-bad)',
};

export default function AlertHistory({ alerts }) {
  return (
    <div className="ts-panel">
      <div className="ts-panel-header">
        <span className="ts-panel-title">Alert History</span>
        <span className="ts-panel-subtitle">Dispatch log</span>
      </div>
      <div className="ts-table-wrap">
        <table className="ts-table">
          <thead>
            <tr>
              <th>Time</th>
              <th>Ward</th>
              <th>Risk</th>
              <th>Channel</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {(!alerts || alerts.length === 0) ? (
              <tr>
                <td colSpan={5} className="ts-empty-state">No alerts have been dispatched yet.</td>
              </tr>
            ) : (
              alerts.map((a) => (
                <tr key={a.id}>
                  <td className="ts-mono">{formatClock(a.triggered_at)}</td>
                  <td className="strong">{a.ward_name}</td>
                  <td><RiskBadge band={a.risk_band} /></td>
                  <td style={{ textTransform: 'uppercase' }}>{a.channel}</td>
                  <td>
                    <span style={{ color: STATUS_COLOR[a.status] || 'var(--text-2)', fontWeight: 600, textTransform: 'uppercase' }}>
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
