import RiskBadge from './RiskBadge';
import { normalizeBand, formatNumber, formatDayLabel } from '../lib/risk';

export default function ForecastOutlook({ days }) {
  return (
    <div className="ts-panel">
      <div className="ts-panel-header">
        <span className="ts-panel-title">Forecast Outlook</span>
        <span className="ts-panel-subtitle">Next 5 days · citywide peak</span>
      </div>
      <div className="ts-panel-body">
        {!days || days.length === 0 ? (
          <div className="ts-empty-state">No forecast data available.</div>
        ) : (
          <div className="ts-outlook-grid">
            {days.map((d, i) => (
              <div key={d.date} className={`ts-outlook-card risk-${normalizeBand(d.risk_band)}`}>
                <div className="ts-outlook-day">{formatDayLabel(d.date, i)}</div>
                <RiskBadge band={d.risk_band} />
                <div className="ts-outlook-metrics">
                  <span>Peak WBGT <b>{formatNumber(d.wbgt)}°C</b></span>
                  <span>Peak UTCI <b>{formatNumber(d.utci)}°C</b></span>
                  <span>Heat Index <b>{formatNumber(d.heat_index)}°C</b></span>
                  <span className="ts-muted" title={d.peak_ward_name}>Driven by {d.peak_ward_name}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
