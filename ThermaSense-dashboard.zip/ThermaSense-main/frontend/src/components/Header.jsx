import { useEffect, useState } from 'react';

export default function Header({ freshnessLabel, systemStatus }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);

  const statusClass =
    systemStatus === 'degraded' ? 'warn' : systemStatus === 'offline' ? 'bad' : '';
  const statusLabel =
    systemStatus === 'degraded'
      ? 'DEGRADED — USING FALLBACK DATA'
      : systemStatus === 'offline'
      ? 'BACKEND UNREACHABLE'
      : 'SYSTEM OPERATIONAL';

  return (
    <header className="ts-header">
      <div className="ts-header-left">
        <span className="ts-wordmark">
          THERMA<span>SENSE</span>
        </span>
        <span className="ts-tagline">Urban Thermal Intelligence &amp; Early Warning</span>
      </div>

      <div className="ts-header-right">
        <div className="ts-header-stat">
          <span className="ts-header-stat-label">Local Time</span>
          <span className="ts-mono">
            {now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>

        <div className="ts-header-stat">
          <span className="ts-header-stat-label">Data Source</span>
          <span>NASA POWER / OpenWeatherMap</span>
        </div>

        <div className="ts-header-stat">
          <span className="ts-header-stat-label">Freshness</span>
          <span className="ts-mono">{freshnessLabel}</span>
        </div>

        <div className="ts-header-stat">
          <span className="ts-header-stat-label">&nbsp;</span>
          <span>
            <span className={`ts-status-dot ${statusClass}`} />
            {statusLabel}
          </span>
        </div>
      </div>
    </header>
  );
}
