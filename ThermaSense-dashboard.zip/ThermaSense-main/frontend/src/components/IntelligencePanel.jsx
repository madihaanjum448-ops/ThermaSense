import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
} from 'recharts';
import RiskBadge from './RiskBadge';
import { formatNumber, formatClock } from '../lib/risk';

function DriverRow({ label, value, unit, max }) {
  const available = value !== null && value !== undefined;
  const pct = available ? Math.max(2, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div className="ts-driver-row">
      <span className="ts-driver-label">{label}</span>
      <div className="ts-driver-track">
        <div className="ts-driver-fill" style={{ width: `${pct}%` }} />
      </div>
      <span className="ts-driver-value">{available ? `${formatNumber(value, 1)}${unit}` : 'N/A'}</span>
    </div>
  );
}

function ChartTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="ts-popup" style={{ background: 'var(--bg-2)', border: '1px solid var(--border-1)', borderRadius: 4, padding: '8px 10px' }}>
      <div className="ts-popup-row"><span>Time</span><b>{formatClock(d.rawTime)}</b></div>
      <div className="ts-popup-row"><span>Risk score</span><b>{formatNumber(d.score)}</b></div>
      <div className="ts-popup-row"><span>Band</span><b>{d.band?.toUpperCase()}</b></div>
    </div>
  );
}

export default function IntelligencePanel({ ward, forecast, drivers, loading }) {
  if (!ward) {
    return (
      <div className="ts-panel ts-intel-panel">
        <div className="ts-panel-header">
          <span className="ts-panel-title">Thermal Risk Intelligence</span>
        </div>
        <div className="ts-panel-body">
          <div className="ts-empty-state">Select a ward on the map to view detailed thermal intelligence.</div>
        </div>
      </div>
    );
  }

  const p = ward.properties;
  const band = p.final_risk_band || p.risk_band;
  const score = p.final_risk_score ?? p.risk_score_raw;

  const chartData = (forecast?.forecasts || []).slice(0, 40).map((f) => ({
    time: new Date(f.score_time).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
      ' ' + new Date(f.score_time).toLocaleTimeString(undefined, { hour: '2-digit' }),
    rawTime: f.score_time,
    score: f.final_risk_score ?? f.risk_score_raw,
    band: f.final_risk_band || f.risk_band,
  }));

  return (
    <div className="ts-intel-panel">
      <div className="ts-panel">
        <div className="ts-panel-header">
          <span className="ts-panel-title">Thermal Risk Intelligence</span>
          <RiskBadge band={band} />
        </div>
        <div className="ts-panel-body">
          <div className="ts-row between" style={{ marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>{p.name}</div>
              <div className="ts-muted" style={{ fontSize: 11 }}>{p.city || 'Ward'} · Score {formatNumber(score)}</div>
            </div>
          </div>

          <div className="ts-metric-grid">
            <div className="ts-metric">
              <div className="ts-metric-label">WBGT</div>
              <div className="ts-metric-value">{formatNumber(p.wbgt)}°C</div>
            </div>
            <div className="ts-metric">
              <div className="ts-metric-label">UTCI</div>
              <div className="ts-metric-value">{formatNumber(p.utci)}°C</div>
            </div>
            <div className="ts-metric">
              <div className="ts-metric-label">Heat Index</div>
              <div className="ts-metric-value">{formatNumber(p.heat_index)}°C</div>
            </div>
          </div>
        </div>
      </div>

      <div className="ts-panel">
        <div className="ts-panel-header">
          <span className="ts-panel-title">Risk Trend — Next 5 Days</span>
        </div>
        <div className="ts-panel-body">
          {chartData.length === 0 ? (
            <div className="ts-empty-state">No forecast data available for this ward.</div>
          ) : (
            <ResponsiveContainer width="100%" height={170}>
              <LineChart data={chartData} margin={{ top: 4, right: 6, left: -18, bottom: 0 }}>
                <CartesianGrid stroke="var(--border-0)" vertical={false} />
                <XAxis
                  dataKey="time"
                  tick={{ fill: 'var(--text-2)', fontSize: 9 }}
                  interval={Math.max(0, Math.floor(chartData.length / 5))}
                  axisLine={{ stroke: 'var(--border-1)' }}
                  tickLine={false}
                />
                <YAxis
                  domain={[0, 100]}
                  tick={{ fill: 'var(--text-2)', fontSize: 9 }}
                  axisLine={false}
                  tickLine={false}
                  width={26}
                />
                <Tooltip content={<ChartTooltip />} />
                <ReferenceLine y={60} stroke="var(--risk-high)" strokeDasharray="3 3" strokeOpacity={0.6} />
                <ReferenceLine y={80} stroke="var(--risk-extreme)" strokeDasharray="3 3" strokeOpacity={0.6} />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="var(--text-0)"
                  strokeWidth={1.75}
                  dot={false}
                  activeDot={{ r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
          <div className="ts-row" style={{ fontSize: 9.5, color: 'var(--text-2)', marginTop: 4, gap: 14 }}>
            <span>-- 60 HIGH threshold</span>
            <span>-- 80 EXTREME threshold</span>
          </div>
        </div>
      </div>

      <div className="ts-panel">
        <div className="ts-panel-header">
          <span className="ts-panel-title">Why Is Risk High?</span>
        </div>
        <div className="ts-panel-body">
          {loading ? (
            <div className="ts-empty-state">Loading current readings…</div>
          ) : drivers?.available ? (
            <>
              <DriverRow label="Temperature" value={drivers.temperature_c} unit="°C" max={45} />
              <DriverRow label="Humidity" value={drivers.humidity_pct} unit="%" max={100} />
              <DriverRow label="Solar Rad." value={drivers.solar_radiation_wm2} unit=" W/m²" max={1000} />
              <DriverRow label="Wind" value={drivers.wind_speed_ms} unit=" m/s" max={10} />
            </>
          ) : (
            <div className="ts-empty-state">No live weather readings available for this ward.</div>
          )}
        </div>
      </div>
    </div>
  );
}
