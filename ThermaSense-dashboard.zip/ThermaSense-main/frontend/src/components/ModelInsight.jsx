// Descriptive thresholds only — used to explain which inputs are elevated
// for the selected ward's current reading. These are not the risk model's
// internal weights (see risk_scoring.py for the actual scoring logic),
// just a readable summary of which raw inputs are currently high.
const FACTORS = [
  { key: 'temperature_c', label: 'High temperature', threshold: 34 },
  { key: 'humidity_pct', label: 'High humidity', threshold: 65 },
  { key: 'solar_radiation_wm2', label: 'Strong solar load', threshold: 650 },
];

export default function ModelInsight({ ward, drivers }) {
  if (!ward) {
    return (
      <div className="ts-panel">
        <div className="ts-panel-header">
          <span className="ts-panel-title">ThermaSense Model Insight</span>
        </div>
        <div className="ts-panel-body">
          <div className="ts-empty-state">Select a ward to see which factors are driving its risk.</div>
        </div>
      </div>
    );
  }

  const contributing = drivers?.available
    ? FACTORS.filter((f) => drivers[f.key] !== null && drivers[f.key] >= f.threshold)
    : [];

  const lowWind = drivers?.available && drivers.wind_speed_ms !== null && drivers.wind_speed_ms < 2;
  if (lowWind) contributing.push({ key: 'wind', label: 'Low wind circulation' });

  return (
    <div className="ts-panel">
      <div className="ts-panel-header">
        <span className="ts-panel-title">ThermaSense Model Insight</span>
        <span className="ts-panel-subtitle">{ward.properties.name}</span>
      </div>
      <div className="ts-panel-body">
        {!drivers?.available ? (
          <div className="ts-empty-state">No live weather readings available to explain this ward's risk.</div>
        ) : contributing.length === 0 ? (
          <div className="ts-empty-state">No individual input is significantly elevated for this ward right now.</div>
        ) : (
          <div className="ts-insight-list">
            <div className="ts-muted" style={{ fontSize: 11, marginBottom: 2 }}>
              Current risk is elevated primarily due to:
            </div>
            {contributing.map((f) => (
              <div className="ts-insight-item" key={f.key}>
                <span className="ts-insight-flag">+</span>
                <b>{f.label}</b>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
