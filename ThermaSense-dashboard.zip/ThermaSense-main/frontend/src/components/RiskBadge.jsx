import { normalizeBand, formatBand } from '../lib/risk';

export default function RiskBadge({ band }) {
  const b = normalizeBand(band);
  return (
    <span className={`ts-badge risk-${b}`}>
      <span className="ts-dot" />
      {formatBand(band)}
    </span>
  );
}
