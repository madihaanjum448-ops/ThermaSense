import { normalizeBand, formatBand, relativeTimeFromNow } from '../lib/risk';

function StripItem({ label, value, valueClass, sub }) {
  return (
    <div className="ts-strip-item">
      <span className="ts-strip-label">{label}</span>
      <span className={`ts-strip-value ${valueClass || ''}`}>{value}</span>
      {sub ? <span className="ts-strip-sub">{sub}</span> : null}
    </div>
  );
}

export default function RiskSummaryStrip({ summary }) {
  if (!summary) {
    return (
      <div className="ts-strip">
        <StripItem label="City Thermal Status" value="—" />
      </div>
    );
  }

  const {
    currentBand,
    peakBand,
    peakTime,
    wardsMonitored,
    highRiskWards,
    activeWarnings,
    lastUpdated,
  } = summary;

  return (
    <div className="ts-strip">
      <StripItem
        label="Current Risk"
        value={formatBand(currentBand)}
        valueClass={`risk-${normalizeBand(currentBand)}`}
      />
      <StripItem
        label="Peak Forecast Risk"
        value={formatBand(peakBand)}
        valueClass={`risk-${normalizeBand(peakBand)}`}
        sub={peakTime ? relativeTimeFromNow(peakTime) : undefined}
      />
      <StripItem label="Wards Monitored" value={wardsMonitored} />
      <StripItem
        label="High-Risk Wards"
        value={highRiskWards}
        valueClass={highRiskWards > 0 ? 'risk-high' : undefined}
      />
      <StripItem
        label="Active Warnings"
        value={activeWarnings}
        valueClass={activeWarnings > 0 ? 'risk-extreme' : undefined}
      />
      <StripItem
        label="Data Freshness"
        value={lastUpdated ? relativeTimeFromNow(lastUpdated) : 'N/A'}
      />
    </div>
  );
}
