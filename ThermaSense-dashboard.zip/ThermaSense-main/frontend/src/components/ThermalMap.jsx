import { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, GeoJSON, useMap } from 'react-leaflet';
import { riskColorVar, normalizeBand, formatBand, formatNumber } from '../lib/risk';

const FALLBACK_WARDS_GEOJSON = {
  type: 'FeatureCollection',
  features: [
    {
      type: 'Feature',
      properties: {
        id: 1,
        name: 'Shivajinagar (Central)',
        wbgt: 33.4,
        utci: 39.8,
        risk_band: 'extreme',
        final_risk_band: 'extreme',
        final_risk_score: 85.2,
      },
      geometry: {
        type: 'Polygon',
        coordinates: [[[77.585, 12.975], [77.615, 12.975], [77.615, 12.995], [77.585, 12.995], [77.585, 12.975]]],
      },
    },
    {
      type: 'Feature',
      properties: {
        id: 2,
        name: 'Koramangala (South-East)',
        wbgt: 30.8,
        utci: 35.2,
        risk_band: 'high',
        final_risk_band: 'high',
        final_risk_score: 61.4,
      },
      geometry: {
        type: 'Polygon',
        coordinates: [[[77.610, 12.920], [77.640, 12.920], [77.640, 12.945], [77.610, 12.945], [77.610, 12.920]]],
      },
    },
    {
      type: 'Feature',
      properties: {
        id: 3,
        name: 'Malleshwaram (North-West)',
        wbgt: 27.5,
        utci: 31.0,
        risk_band: 'moderate',
        final_risk_band: 'moderate',
        final_risk_score: 38.5,
      },
      geometry: {
        type: 'Polygon',
        coordinates: [[[77.555, 12.990], [77.580, 12.990], [77.580, 13.015], [77.555, 13.015], [77.555, 12.990]]],
      },
    },
  ],
};

function resolveCssColor(varExpr) {
  // Leaflet needs a resolved color string, not a raw CSS var() reference,
  // for canvas/SVG paint — read it off the document root.
  const varName = varExpr.replace('var(', '').replace(')', '').trim();
  return getComputedStyle(document.documentElement).getPropertyValue(varName).trim() || '#5b6472';
}

function FitMapToGeoJSON({ geoData }) {
  const map = useMap();
  useEffect(() => {
    if (geoData?.features?.length) {
      const layer = new window.L.GeoJSON(geoData);
      const bounds = layer.getBounds();
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [30, 30], maxZoom: 13 });
      }
    }
  }, [geoData, map]);
  return null;
}

export default function ThermalMap({ onSelectWard, selectedWardId, geoData: liveGeoData, loadError }) {
  const geoJsonRef = useRef(null);
  const geoData = liveGeoData?.features?.length ? liveGeoData : FALLBACK_WARDS_GEOJSON;
  const statusMsg = loadError
    ? 'Backend unavailable — showing demo data'
    : liveGeoData?.features?.length
    ? `${liveGeoData.features.length} wards live`
    : 'Loading ward risk data…';

  const styleFeature = (feature) => {
    const band = feature.properties.final_risk_band || feature.properties.risk_band;
    const isSelected = feature.properties.id === selectedWardId;
    return {
      color: isSelected ? '#e6eaf0' : '#0c1017',
      weight: isSelected ? 2 : 1,
      fillColor: resolveCssColor(riskColorVar(band)),
      fillOpacity: normalizeBand(band) === 'unknown' ? 0.25 : 0.55,
    };
  };

  const onEachFeature = (feature, layer) => {
    const p = feature.properties;
    const band = p.final_risk_band || p.risk_band;

    layer.bindPopup(
      `<div class="ts-popup">
        <div class="ts-popup-title">${p.name || 'Ward'}</div>
        <div class="ts-popup-row"><span>Risk band</span><b>${formatBand(band)}</b></div>
        <div class="ts-popup-row"><span>Risk score</span><b>${formatNumber(p.final_risk_score ?? p.risk_score_raw)}</b></div>
        <div class="ts-popup-row"><span>WBGT</span><b>${formatNumber(p.wbgt)}°C</b></div>
        <div class="ts-popup-row"><span>UTCI</span><b>${formatNumber(p.utci)}°C</b></div>
      </div>`,
      { className: 'ts-leaflet-popup' }
    );

    layer.on('click', () => onSelectWard?.(p.id));
    layer.on('mouseover', () => layer.setStyle({ weight: 2 }));
    layer.on('mouseout', () => layer.setStyle({ weight: feature.properties.id === selectedWardId ? 2 : 1 }));
  };

  return (
    <div className="ts-panel ts-map-panel">
      <div className="ts-panel-header">
        <span className="ts-panel-title">City Thermal Risk Map</span>
        <span className="ts-panel-subtitle">{statusMsg}</span>
      </div>

      <div className="ts-map-wrap">
        <MapContainer center={[12.9716, 77.5946]} zoom={11} style={{ height: '100%', width: '100%' }}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {geoData && (
            <>
              <FitMapToGeoJSON geoData={geoData} />
              <GeoJSON
                ref={geoJsonRef}
                key={JSON.stringify(geoData) + selectedWardId}
                data={geoData}
                style={styleFeature}
                onEachFeature={onEachFeature}
              />
            </>
          )}
        </MapContainer>

        <div className="ts-map-legend">
          {['extreme', 'high', 'moderate', 'low'].map((band) => (
            <div className="ts-map-legend-item" key={band}>
              <span className="ts-map-legend-swatch" style={{ background: resolveCssColor(riskColorVar(band)) }} />
              {formatBand(band)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
