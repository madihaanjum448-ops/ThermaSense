import RiskBadge from './RiskBadge';
import { formatNumber, formatBand, relativeTimeFromNow } from '../lib/risk';

const TREND_ARROW = { increasing: '↑', decreasing: '↓', stable: '→', unknown: '—' };

export default function WardPriorityTable({ wards, onSelectWard, selectedWardId }) {
  return (
    <div className="ts-panel">
      <div className="ts-panel-header">
        <span className="ts-panel-title">Ward Priority Queue</span>
        <span className="ts-panel-subtitle">{wards.length} wards, sorted by current risk</span>
      </div>
      <div className="ts-table-wrap">
        <table className="ts-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Ward</th>
              <th>Current Risk</th>
              <th>Score</th>
              <th>Forecast Peak</th>
              <th>Trend</th>
              <th>Warning</th>
              <th>Last Updated</th>
            </tr>
          </thead>
          <tbody>
            {wards.map((w, i) => (
              <tr
                key={w.ward_id}
                className={`selectable ${w.ward_id === selectedWardId ? 'selected' : ''}`}
                onClick={() => onSelectWard?.(w.ward_id)}
              >
                <td>{i + 1}</td>
                <td className="strong">{w.ward_name}</td>
                <td><RiskBadge band={w.current?.risk_band} /></td>
                <td className="ts-mono">{formatNumber(w.current?.risk_score)}</td>
                <td>
                  {w.forecast_peak ? (
                    <span className={`ts-badge risk-${(w.forecast_peak.risk_band || 'unknown').toLowerCase()}`}>
                      {formatBand(w.forecast_peak.risk_band)}
                    </span>
                  ) : (
                    <span className="ts-muted">N/A</span>
                  )}
                </td>
                <td className={`ts-trend ${w.trend}`}>{TREND_ARROW[w.trend] || '—'}</td>
                <td>{w.warning ? <span style={{ color: 'var(--risk-extreme)', fontWeight: 700 }}>●</span> : <span className="ts-muted">—</span>}</td>
                <td className="ts-muted">{w.last_updated ? relativeTimeFromNow(w.last_updated) : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
