import { normalizeBand, formatBand, formatClock } from '../lib/risk';

export default function WarningPanel({ warnings, onSelectWard }) {
  return (
    <div className="ts-panel">
      <div className="ts-panel-header">
        <span className="ts-panel-title">Early Warning Status</span>
        <span className="ts-panel-subtitle">{warnings.length} active</span>
      </div>
      <div className="ts-panel-body">
        {warnings.length === 0 ? (
          <div className="ts-empty-state">No active HIGH or EXTREME forecast warnings.</div>
        ) : (
          <div className="ts-warning-list">
            {warnings.map((w) => (
              <div
                key={w.ward_id}
                className={`ts-warning-item risk-${normalizeBand(w.warning.risk_band)}`}
                onClick={() => onSelectWard?.(w.ward_id)}
                style={{ cursor: 'pointer' }}
              >
                <div className="ts-warning-body">
                  <div className="ts-warning-title">
                    {formatBand(w.warning.risk_band)} HEAT RISK — {w.ward_name}
                  </div>
                  <div className="ts-warning-meta">
                    Expected {formatClock(w.warning.expected_time)} · lead time{' '}
                    {w.warning.lead_time_hours}h · score {w.warning.risk_score?.toFixed(1)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
